import { NextRequest, NextResponse } from "next/server";
import {
  redis,
  K,
  HEARTBEAT_TTL_SECONDS,
  MAX_TRADES,
  MAX_REJECTS,
} from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type AnyEvent = Record<string, unknown> & { type?: string; magic?: number };

// Constant-time-ish compare. The secret is short and this endpoint is not a
// login, but there is no reason to leak length/prefix through early exit.
function secretOk(provided: string | null): boolean {
  const expected = process.env.EA_INGEST_KEY ?? "";
  if (!expected) return false;
  if (!provided) return false;
  if (provided.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) {
    diff |= provided.charCodeAt(i) ^ expected.charCodeAt(i);
  }
  return diff === 0;
}

export async function POST(req: NextRequest) {
  if (!secretOk(req.headers.get("x-ea-key"))) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  let body: { events?: AnyEvent[] };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "invalid json" }, { status: 400 });
  }

  const events = Array.isArray(body?.events) ? body.events : [];
  if (events.length === 0) return NextResponse.json({ ok: true, accepted: 0 });
  if (events.length > 200) {
    return NextResponse.json({ error: "batch too large" }, { status: 413 });
  }

  const pipe = redis.pipeline();
  let accepted = 0;

  for (const ev of events) {
    const magic = typeof ev.magic === "number" ? ev.magic : 0;
    switch (ev.type) {
      case "heartbeat":
        pipe.set(K.heartbeat(magic), { ...ev, received_at: Date.now() }, {
          ex: HEARTBEAT_TTL_SECONDS,
        });
        pipe.sadd(K.magics, String(magic));
        accepted++;
        break;
      case "trade":
        pipe.lpush(K.trades, JSON.stringify(ev));
        pipe.ltrim(K.trades, 0, MAX_TRADES - 1);
        accepted++;
        break;
      case "reject":
        pipe.lpush(K.rejects, JSON.stringify(ev));
        pipe.ltrim(K.rejects, 0, MAX_REJECTS - 1);
        accepted++;
        break;
      default:
        break; // unknown type: ignore rather than fail the whole batch
    }
  }

  await pipe.exec();
  return NextResponse.json({ ok: true, accepted });
}
