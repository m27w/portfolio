import { NextResponse } from "next/server";
import { redis, K, type Trade, type Reject, type Heartbeat } from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function parseList<T>(rows: unknown[]): T[] {
  const out: T[] = [];
  for (const r of rows) {
    if (typeof r === "string") {
      try {
        out.push(JSON.parse(r) as T);
      } catch {
        /* skip malformed row rather than 500 the whole dashboard */
      }
    } else if (r && typeof r === "object") {
      out.push(r as T);
    }
  }
  return out;
}

// R buckets are fixed, not data-derived, so the histogram shape is comparable
// across sessions instead of silently rescaling as trades arrive.
const R_BUCKETS: { label: string; lo: number; hi: number }[] = [
  { label: "< -2", lo: -Infinity, hi: -2 },
  { label: "-2..-1.5", lo: -2, hi: -1.5 },
  { label: "-1.5..-1", lo: -1.5, hi: -1 },
  { label: "-1..-0.5", lo: -1, hi: -0.5 },
  { label: "-0.5..0", lo: -0.5, hi: 0 },
  { label: "0..0.5", lo: 0, hi: 0.5 },
  { label: "0.5..1", lo: 0.5, hi: 1 },
  { label: "1..1.5", lo: 1, hi: 1.5 },
  { label: "1.5..2", lo: 1.5, hi: 2 },
  { label: "> 2", lo: 2, hi: Infinity },
];

export async function GET() {
  const magics = (await redis.smembers(K.magics)) as string[];

  const heartbeats: Heartbeat[] = [];
  for (const m of magics) {
    const hb = (await redis.get(K.heartbeat(m))) as Heartbeat | null;
    if (hb) heartbeats.push(hb);
  }

  const [tradeRows, rejectRows] = await Promise.all([
    redis.lrange(K.trades, 0, 1999),
    redis.lrange(K.rejects, 0, 4999),
  ]);

  // Stored newest-first by LPUSH; charts read chronologically.
  const trades = parseList<Trade>(tradeRows).reverse();
  const rejects = parseList<Reject>(rejectRows).reverse();

  const wins = trades.filter((t) => t.net > 0);
  const losses = trades.filter((t) => t.net <= 0);
  const grossWin = wins.reduce((a, t) => a + t.net, 0);
  const grossLoss = Math.abs(losses.reduce((a, t) => a + t.net, 0));
  const totalR = trades.reduce((a, t) => a + (Number.isFinite(t.r) ? t.r : 0), 0);

  // Max drawdown walked on the realised balance series, not on peak equity -
  // this is the closed-trade drawdown, which is what the R stats describe.
  let peak = -Infinity;
  let maxDD = 0;
  const equityCurve = trades.map((t) => {
    if (t.balance > peak) peak = t.balance;
    const dd = peak - t.balance;
    if (dd > maxDD) maxDD = dd;
    return { t: t.close_time, balance: t.balance, r: t.r, reason: t.reason };
  });

  const rHist = R_BUCKETS.map((b) => ({
    label: b.label,
    sign: b.hi <= 0 ? ("neg" as const) : ("pos" as const),
    count: trades.filter((t) => t.r >= b.lo && t.r < b.hi).length,
  }));

  const rejectCounts = new Map<string, number>();
  for (const r of rejects) {
    rejectCounts.set(r.filter, (rejectCounts.get(r.filter) ?? 0) + 1);
  }
  const rejectBreakdown = [...rejectCounts.entries()]
    .map(([filter, count]) => ({ filter, count }))
    .sort((a, b) => b.count - a.count);

  const reasonCounts = new Map<string, number>();
  for (const t of trades) {
    reasonCounts.set(t.reason, (reasonCounts.get(t.reason) ?? 0) + 1);
  }

  // Slipped stops: R materially worse than -1 is execution cost, not strategy.
  const slipped = trades.filter((t) => t.r < -1.05).length;

  return NextResponse.json(
    {
      generated_at: Date.now(),
      heartbeats,
      kpi: {
        trades: trades.length,
        wins: wins.length,
        winRate: trades.length ? (wins.length / trades.length) * 100 : 0,
        totalR,
        expectancyR: trades.length ? totalR / trades.length : 0,
        profitFactor: grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? Infinity : 0,
        netPL: grossWin - grossLoss,
        avgWin: wins.length ? grossWin / wins.length : 0,
        avgLoss: losses.length ? grossLoss / losses.length : 0,
        maxDD,
        slipped,
        slippedPct: losses.length ? (slipped / losses.length) * 100 : 0,
        rejects: rejects.length,
      },
      equityCurve,
      rHist,
      rejectBreakdown,
      exitReasons: [...reasonCounts.entries()]
        .map(([reason, count]) => ({ reason, count }))
        .sort((a, b) => b.count - a.count),
      recentTrades: trades.slice(-25).reverse(),
      recentRejects: rejects.slice(-25).reverse(),
    },
    { headers: { "cache-control": "no-store" } }
  );
}
