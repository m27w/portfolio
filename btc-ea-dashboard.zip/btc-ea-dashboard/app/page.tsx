"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Stats = {
  generated_at: number;
  heartbeats: any[];
  kpi: {
    trades: number; wins: number; winRate: number; totalR: number; expectancyR: number;
    profitFactor: number; netPL: number; avgWin: number; avgLoss: number; maxDD: number;
    slipped: number; slippedPct: number; rejects: number;
  };
  equityCurve: { t: string; balance: number; r: number; reason: string }[];
  rHist: { label: string; sign: "neg" | "pos"; count: number }[];
  rejectBreakdown: { filter: string; count: number }[];
  exitReasons: { reason: string; count: number }[];
  recentTrades: any[];
  recentRejects: any[];
};

type Tip = { x: number; y: number; html: React.ReactNode } | null;

const n = (v: number, d = 2) =>
  Number.isFinite(v) ? v.toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d }) : "—";

export default function Page() {
  const [data, setData] = useState<Stats | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [tip, setTip] = useState<Tip>(null);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/stats", { cache: "no-store" });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      setData(await r.json());
      setErr(null);
    } catch (e: any) {
      setErr(e?.message ?? "fetch failed");
    }
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, [load]);

  const hb = data?.heartbeats?.[0];
  const stale = hb?.received_at ? Date.now() - hb.received_at > 90_000 : true;

  return (
    <div className="wrap">
      <header className="top">
        <div>
          <h1>BTC EA Telemetry</h1>
          <p className="sub">
            {hb ? `${hb.symbol} ${hb.tf?.replace("PERIOD_", "")} · magic ${hb.magic}` : "waiting for first heartbeat"}
            {data ? ` · refreshed ${new Date(data.generated_at).toLocaleTimeString()}` : ""}
          </p>
        </div>
        <StatusPill hb={hb} stale={stale} err={err} />
      </header>

      {!data ? (
        <div className="card"><p className="empty">Connecting…</p></div>
      ) : (
        <>
          <Kpis k={data.kpi} hb={hb} />

          <div className="grid-2">
            <Filters hb={hb} stale={stale} />
            <LiveTrade hb={hb} />
          </div>

          <div className="stack">
            <div className="card">
              <h2>Realised balance</h2>
              <p className="note">Closed trades only, in account currency. Hover for the trade at that point.</p>
              <EquityCurve rows={data.equityCurve} setTip={setTip} />
            </div>

            <div className="grid-2">
              <div className="card">
                <h2>R multiple distribution</h2>
                <p className="note">
                  Bars left of zero are losses. Anything below −1 is stop slippage, not strategy.
                </p>
                <RHistogram rows={data.rHist} setTip={setTip} />
              </div>

              <div className="card">
                <h2>What the filters are costing you</h2>
                <p className="note">Rejected signals by filter. The headline diagnostic for this feed.</p>
                <RejectBars rows={data.rejectBreakdown} setTip={setTip} />
              </div>
            </div>

            <div className="grid-2">
              <div className="card">
                <h2>Recent trades</h2>
                <p className="note">Newest first.</p>
                <TradeTable rows={data.recentTrades} />
              </div>
              <div className="card">
                <h2>Recent rejections</h2>
                <p className="note">Newest first, with the numbers that triggered them.</p>
                <RejectTable rows={data.recentRejects} />
              </div>
            </div>
          </div>
        </>
      )}

      {tip && (
        <div className="tip" style={{ left: tip.x + 14, top: tip.y + 14 }}>
          {tip.html}
        </div>
      )}
    </div>
  );
}

function StatusPill({ hb, stale, err }: { hb: any; stale: boolean; err: string | null }) {
  let color = "var(--ink-muted)";
  let label = "no data";
  if (err) { color = "var(--critical)"; label = `dashboard error · ${err}`; }
  else if (!hb) { color = "var(--warning)"; label = "waiting for EA"; }
  else if (stale) { color = "var(--critical)"; label = "heartbeat stale"; }
  else if (hb.halted) { color = "var(--critical)"; label = "HALTED · equity floor"; }
  else if (hb.day_blocked) { color = "var(--critical)"; label = "BLOCKED · daily loss cap"; }
  else if (hb.lockout) { color = "var(--critical)"; label = "LOCKED OUT · loss streak"; }
  else if (hb.in_trade) { color = "var(--warning)"; label = "IN TRADE"; }
  else { color = "var(--good)"; label = "ARMED"; }
  return (
    <div className="statusrow">
      <span className="dot" style={{ background: color }} aria-hidden />
      <strong style={{ fontSize: 13 }}>{label}</strong>
    </div>
  );
}

function Tile({ label, value, foot, tone }: { label: string; value: string; foot?: string; tone?: string }) {
  return (
    <div className="card tile">
      <p className="label">{label}</p>
      <div className="value" style={tone ? { color: tone } : undefined}>{value}</div>
      {foot && <div className="foot">{foot}</div>}
    </div>
  );
}

function Kpis({ k, hb }: { k: Stats["kpi"]; hb: any }) {
  const pf = k.profitFactor;
  const pfTone = !k.trades ? undefined : pf >= 1.25 ? "var(--good)" : pf >= 1 ? "var(--warning)" : "var(--critical)";
  const expTone = !k.trades ? undefined : k.expectancyR > 0 ? "var(--good)" : "var(--critical)";
  const slipTone = k.slippedPct > 10 ? "var(--critical)" : undefined;
  return (
    <div className="grid-kpi">
      <Tile label="Equity" value={hb ? n(hb.equity) : "—"} foot={hb ? `${hb.ccy} · balance ${n(hb.balance)}` : undefined} />
      <Tile label="Closed trades" value={String(k.trades)} foot={`${k.wins} wins · ${n(k.winRate, 1)}% win rate`} />
      <Tile label="Profit factor" value={k.trades ? (Number.isFinite(pf) ? n(pf) : "∞") : "—"} tone={pfTone} foot="gross win ÷ gross loss" />
      <Tile label="Expectancy" value={k.trades ? `${k.expectancyR >= 0 ? "+" : ""}${n(k.expectancyR, 3)}R` : "—"} tone={expTone} foot={`total ${k.totalR >= 0 ? "+" : ""}${n(k.totalR, 2)}R`} />
      <Tile label="Max drawdown" value={n(k.maxDD)} foot="on realised balance" />
      <Tile label="Slipped stops" value={k.trades ? `${n(k.slippedPct, 0)}%` : "—"} tone={slipTone} foot={`${k.slipped} losers worse than −1R`} />
    </div>
  );
}

function FilterLine({ label, ok, detail }: { label: string; ok: boolean; detail: string }) {
  return (
    <div className="filterline">
      <span className="dot" style={{ background: ok ? "var(--good)" : "var(--critical)" }} aria-hidden />
      <span className="k">{label}</span>
      <span className="v">{detail}</span>
      <span style={{ color: ok ? "var(--good)" : "var(--critical)", fontSize: 11, fontWeight: 600 }}>
        {ok ? "PASS" : "BLOCK"}
      </span>
    </div>
  );
}

function Filters({ hb, stale }: { hb: any; stale: boolean }) {
  if (!hb) return <div className="card"><h2>Entry gates</h2><p className="empty">No heartbeat yet.</p></div>;
  return (
    <div className="card">
      <h2>Entry gates</h2>
      <p className="note">
        {stale ? "Stale — the EA has not reported in over 90s." : `Live as of ${hb.ts} broker time.`}
      </p>
      <div className="filters">
        <FilterLine label="Trend" ok={hb.trend === "UP" || hb.trend === "DOWN"} detail={hb.trend === "UP" ? "longs only" : hb.trend === "DOWN" ? "shorts only" : "flat"} />
        <FilterLine label="ATR" ok={hb.atr_ok} detail={`${n(hb.atr_pts, 0)} / ${hb.atr_min}–${hb.atr_max}`} />
        <FilterLine label="Spread" ok={hb.spread_ok} detail={`${n(hb.spread_pts, 0)} / max ${hb.spread_max}`} />
        <FilterLine label="Cost" ok={hb.cost_ok} detail={`${n(hb.cost_pct, 1)}% / max ${n(hb.cost_max, 0)}%`} />
        <FilterLine label="Session" ok={hb.session_ok} detail={hb.ts?.slice(-8) ?? ""} />
        <FilterLine label="Weekend" ok={!hb.weekend_block} detail={hb.weekend_block ? "blocked" : "clear"} />
        <FilterLine label="News" ok={!hb.news_block} detail={hb.news_block ? "blackout" : "clear"} />
        <FilterLine label="Lockout" ok={!hb.lockout} detail={`streak ${hb.consec_losses}`} />
        <FilterLine label="Daily cap" ok={!hb.day_blocked} detail={`${n(hb.day_pct, 2)}% / ${n(-hb.day_cap_pct, 2)}%`} />
        <FilterLine label="Floor" ok={!hb.halted} detail={`${n(hb.floor, 0)} = ${n(hb.floor_pct, 1)}% DD`} />
        <FilterLine label="Lot size" ok={hb.lots_now >= hb.lot_min} detail={`${n(hb.lots_now)} / min ${n(hb.lot_min)}`} />
        <FilterLine label="Feed" ok={hb.queued < 20} detail={`${hb.queued} queued`} />
      </div>
    </div>
  );
}

function LiveTrade({ hb }: { hb: any }) {
  return (
    <div className="card">
      <h2>Position</h2>
      <p className="note">{hb?.in_trade ? "Open now." : "Flat — waiting for a confirmed bar close."}</p>
      {hb?.in_trade ? (
        <>
          <div className="value" style={{ fontSize: 30, fontWeight: 640, color: hb.pos_r >= 0 ? "var(--pos)" : "var(--neg)" }}>
            {hb.pos_r >= 0 ? "+" : ""}{n(hb.pos_r, 2)}R
          </div>
          <div className="foot" style={{ marginTop: 8, color: "var(--ink-2)", fontSize: 13 }}>
            {hb.pos_dir} {n(hb.pos_lots)} lots · bar {hb.bars_in_trade}/{hb.max_bars} ·{" "}
            {hb.trailing ? "trailing" : hb.be_armed ? "at break-even" : "initial stop"}
          </div>
        </>
      ) : (
        <div className="foot" style={{ fontSize: 13, color: "var(--ink-2)" }}>
          Today: {hb?.day_trades ?? 0} trades · {hb?.day_wins ?? 0} wins ·{" "}
          {hb ? `${hb.day_gross_r >= 0 ? "+" : ""}${n(hb.day_gross_r, 2)}R` : "—"}
          <div style={{ marginTop: 10, color: "var(--ink-muted)" }}>Last: {hb?.last_event ?? "—"}</div>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------- charts --- */

const W = 760, H = 220, PAD = { t: 12, r: 14, b: 26, l: 52 };

function EquityCurve({ rows, setTip }: { rows: Stats["equityCurve"]; setTip: (t: Tip) => void }) {
  const ref = useRef<SVGSVGElement>(null);
  const [hi, setHi] = useState<number | null>(null);

  const { path, pts, lo, hiV } = useMemo(() => {
    if (rows.length < 2) return { path: "", pts: [] as { x: number; y: number }[], lo: 0, hiV: 0 };
    const vals = rows.map((r) => r.balance);
    let lo = Math.min(...vals), hiV = Math.max(...vals);
    if (lo === hiV) { lo -= 1; hiV += 1; }
    const pad = (hiV - lo) * 0.08;
    lo -= pad; hiV += pad;
    const iw = W - PAD.l - PAD.r, ih = H - PAD.t - PAD.b;
    const pts = rows.map((r, i) => ({
      x: PAD.l + (i / (rows.length - 1)) * iw,
      y: PAD.t + ih - ((r.balance - lo) / (hiV - lo)) * ih,
    }));
    return { path: pts.map((p, i) => `${i ? "L" : "M"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" "), pts, lo, hiV };
  }, [rows]);

  if (rows.length < 2) return <p className="empty">Needs at least two closed trades.</p>;

  const onMove = (e: React.MouseEvent) => {
    const box = ref.current?.getBoundingClientRect();
    if (!box) return;
    const rel = ((e.clientX - box.left) / box.width) * W;
    let best = 0, bd = Infinity;
    pts.forEach((p, i) => { const d = Math.abs(p.x - rel); if (d < bd) { bd = d; best = i; } });
    setHi(best);
    const r = rows[best];
    setTip({
      x: e.clientX, y: e.clientY,
      html: (<><b>{n(r.balance)}</b><br />{r.t}<br />{r.reason} · {r.r >= 0 ? "+" : ""}{n(r.r, 2)}R</>),
    });
  };

  const ticks = [0, 0.5, 1].map((f) => lo + (hiV - lo) * f);

  return (
    <svg ref={ref} viewBox={`0 0 ${W} ${H}`} width="100%" role="img"
         aria-label="Realised balance over closed trades"
         onMouseMove={onMove} onMouseLeave={() => { setHi(null); setTip(null); }}>
      {ticks.map((v, i) => {
        const y = PAD.t + (H - PAD.t - PAD.b) * (1 - i / 2);
        return (<g key={i}>
          <line className="gridline" x1={PAD.l} x2={W - PAD.r} y1={y} y2={y} />
          <text className="axis" x={PAD.l - 8} y={y + 3} textAnchor="end">{v.toFixed(0)}</text>
        </g>);
      })}
      <path d={path} fill="none" stroke="var(--series)" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
      {hi !== null && (<>
        <line className="baseline" x1={pts[hi].x} x2={pts[hi].x} y1={PAD.t} y2={H - PAD.b} />
        <circle cx={pts[hi].x} cy={pts[hi].y} r={4.5} fill="var(--series)" stroke="var(--surface)" strokeWidth={2} />
      </>)}
      <line className="baseline" x1={PAD.l} x2={W - PAD.r} y1={H - PAD.b} y2={H - PAD.b} />
      <text className="axis" x={PAD.l} y={H - 8}>{rows[0].t}</text>
      <text className="axis" x={W - PAD.r} y={H - 8} textAnchor="end">{rows[rows.length - 1].t}</text>
    </svg>
  );
}

function RHistogram({ rows, setTip }: { rows: Stats["rHist"]; setTip: (t: Tip) => void }) {
  const total = rows.reduce((a, r) => a + r.count, 0);
  if (!total) return <p className="empty">No closed trades yet.</p>;
  const w = 380, h = 200, pad = { t: 10, r: 8, b: 44, l: 30 };
  const iw = w - pad.l - pad.r, ih = h - pad.t - pad.b;
  const max = Math.max(...rows.map((r) => r.count), 1);
  const bw = iw / rows.length;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" role="img" aria-label="Distribution of R multiples">
      {[0, 0.5, 1].map((f, i) => {
        const y = pad.t + ih * (1 - f);
        return (<g key={i}>
          <line className="gridline" x1={pad.l} x2={w - pad.r} y1={y} y2={y} />
          <text className="axis" x={pad.l - 6} y={y + 3} textAnchor="end">{Math.round(max * f)}</text>
        </g>);
      })}
      {rows.map((r, i) => {
        const bh = (r.count / max) * ih;
        const x = pad.l + i * bw + 1;      /* 2px surface gap between bars */
        const y = pad.t + ih - bh;
        const fill = r.sign === "neg" ? "var(--neg)" : "var(--pos)";
        return (
          <g key={r.label}
             onMouseMove={(e) => setTip({ x: e.clientX, y: e.clientY, html: (<><b>{r.count}</b> trades<br />{r.label} R</>) })}
             onMouseLeave={() => setTip(null)}>
            <rect x={x} y={pad.t} width={bw - 2} height={ih} fill="transparent" />
            {r.count > 0 && <rect x={x} y={y} width={bw - 2} height={bh} rx={3} fill={fill} />}
            <text className="axis" x={x + (bw - 2) / 2} y={h - 26} textAnchor="end"
                  transform={`rotate(-45 ${x + (bw - 2) / 2} ${h - 26})`}>{r.label}</text>
          </g>
        );
      })}
      <line className="baseline" x1={pad.l} x2={w - pad.r} y1={pad.t + ih} y2={pad.t + ih} />
      <text className="axis" x={pad.l} y={h - 4} style={{ fill: "var(--neg)" }}>losses</text>
      <text className="axis" x={w - pad.r} y={h - 4} textAnchor="end" style={{ fill: "var(--pos)" }}>wins</text>
    </svg>
  );
}

function RejectBars({ rows, setTip }: { rows: Stats["rejectBreakdown"]; setTip: (t: Tip) => void }) {
  if (!rows.length) return <p className="empty">No rejected signals recorded yet.</p>;
  const top = rows.slice(0, 9);
  const total = rows.reduce((a, r) => a + r.count, 0);
  const max = Math.max(...top.map((r) => r.count), 1);
  const rowH = 24, labelW = 140, valW = 62;
  const h = top.length * rowH + 8;
  const w = 380;
  const barW = w - labelW - valW;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" role="img" aria-label="Rejected signals by filter">
      {top.map((r, i) => {
        const y = i * rowH + 4;
        const bw = Math.max((r.count / max) * barW, 2);
        const pct = ((r.count / total) * 100).toFixed(0);
        return (
          <g key={r.filter}
             onMouseMove={(e) => setTip({ x: e.clientX, y: e.clientY, html: (<><b>{r.filter}</b><br />{r.count} rejections · {pct}% of all</>) })}
             onMouseLeave={() => setTip(null)}>
            <rect x={0} y={y} width={w} height={rowH - 2} fill="transparent" />
            <text className="axis" x={labelW - 10} y={y + rowH / 2 + 3} textAnchor="end"
                  style={{ fill: "var(--ink-2)", fontSize: 11 }}>{r.filter}</text>
            <rect x={labelW} y={y + 4} width={bw} height={rowH - 12} rx={3} fill="var(--series)" />
            <text className="axis" x={labelW + bw + 8} y={y + rowH / 2 + 3}
                  style={{ fill: "var(--ink-2)" }}>{r.count} · {pct}%</text>
          </g>
        );
      })}
    </svg>
  );
}

function TradeTable({ rows }: { rows: any[] }) {
  if (!rows?.length) return <p className="empty">No trades yet.</p>;
  return (
    <div className="scroll">
      <table>
        <thead><tr><th>Closed</th><th>Dir</th><th>Exit</th><th>R</th><th>Net</th></tr></thead>
        <tbody>
          {rows.map((t, i) => (
            <tr key={i}>
              <td>{t.close_time}</td>
              <td className="sym">{t.dir}</td>
              <td className="sym">{t.reason}</td>
              <td style={{ color: t.r >= 0 ? "var(--pos)" : "var(--neg)" }}>{t.r >= 0 ? "+" : ""}{n(t.r, 2)}</td>
              <td style={{ color: t.net >= 0 ? "var(--pos)" : "var(--neg)" }}>{n(t.net)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function RejectTable({ rows }: { rows: any[] }) {
  if (!rows?.length) return <p className="empty">No rejections yet.</p>;
  return (
    <div className="scroll">
      <table>
        <thead><tr><th>Time</th><th>Dir</th><th>Filter</th><th>Detail</th></tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              <td>{r.ts}</td>
              <td className="sym">{r.dir}</td>
              <td className="sym">{r.filter}</td>
              <td>{r.detail}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
