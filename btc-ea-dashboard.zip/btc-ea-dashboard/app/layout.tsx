import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BTC EA Telemetry",
  description: "Live state and statistics for the BTCUSD M1 momentum-pullback Expert Advisor.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark">
      <body>{children}</body>
    </html>
  );
}
