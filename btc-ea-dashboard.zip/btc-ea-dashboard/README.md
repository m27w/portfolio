# BTC EA Telemetry Dashboard

Live browser dashboard for the BTCUSD M1 momentum-pullback Expert Advisor
(`BtcMomentumPullbackScalper.mq5`, v3.10+).

This is a **standalone project**. Deploy it as its own Vercel project — do not
merge it into an existing one.

```
MT5 EA ──WebRequest POST──▶ /api/ingest ──▶ Upstash Redis
                                                  │
  browser ◀── /api/stats ◀── aggregation ◀────────┘
```

The EA never blocks its trading loop on the network: events are queued in
`OnTick` and flushed from `OnTimer`, so a slow or dead endpoint cannot delay a
stop modification.

---

## 1. Deploy

```bash
git init && git add -A && git commit -m "btc ea dashboard"
# push to a NEW repo, then in Vercel: Add New → Project → import that repo
```

Framework preset: **Next.js**. No build overrides needed.

## 2. Attach Redis

Vercel KV was retired and migrated to Upstash. In your new project:

**Storage → Create Database → Marketplace → Upstash for Redis.**

The integration injects the connection env vars automatically. `lib/store.ts`
accepts either the modern `UPSTASH_REDIS_REST_*` naming or the legacy
`KV_REST_API_*` naming, so it works whichever way the store was provisioned.

## 3. Set the shared secret

```bash
openssl rand -hex 24
```

Add it in Vercel → Settings → Environment Variables as **`EA_INGEST_KEY`**
(all environments). Redeploy so it takes effect.

Requests to `/api/ingest` without a matching `x-ea-key` header get a 401. The
compare is length-checked and non-short-circuiting.

## 4. Whitelist the endpoint in MT5

MetaTrader blocks `WebRequest` by default.

**Tools → Options → Expert Advisors → Allow WebRequest for listed URL**, then
add your app origin exactly:

```
https://your-app.vercel.app
```

Miss this and the EA logs `TELEMETRY: URL not permitted` with error 4060, and
the panel's bottom row reads `Telemetry FAIL`.

## 5. Configure the EA

In the EA's Inputs tab, under **Telemetry (browser dashboard)**:

| Input | Value |
|---|---|
| `InpTelemetryEnabled` | `true` |
| `InpTelemetryUrl` | `https://your-app.vercel.app/api/ingest` |
| `InpTelemetryKey` | the same secret as `EA_INGEST_KEY` |
| `InpTelemetrySec` | `30` |

The on-chart panel's bottom row becomes the feed status: `Telemetry OK HTTP 200
queued 0` once it is working.

---

## What the dashboard shows

- **KPI tiles** — equity, closed trades, profit factor, expectancy per trade,
  max drawdown on realised balance, and the share of losers worse than −1R
  (stop slippage, which the backtest will always understate).
- **Entry gates** — every filter's live pass/block state, mirroring the on-chart
  panel so the browser and the terminal never tell different stories.
- **Realised balance** — closed-trade equity curve with a hover crosshair.
- **R multiple distribution** — fixed buckets so the shape stays comparable
  between sessions instead of rescaling as trades arrive. Losses read left,
  wins right, and the sign is carried by the axis labels as well as colour.
- **Filter cost breakdown** — rejected signals by filter, ranked. `SPREAD` and
  `COST_RATIO` dominating here is the verdict on whether M1 scalping is viable
  on this feed at all.

## Notes

- `/api/stats` is public. It exposes trade statistics for a demo account — no
  credentials, no account number, no broker identity. If you want it private,
  put Vercel Authentication in front of the project (Settings → Deployment
  Protection) — that covers the page and the route without code changes.
- Redis holds the last 2,000 trades and 5,000 rejections; heartbeats expire
  after 180s so a dead EA reads as *stale* rather than as healthy-forever.
- Local dev: copy `.env.example` to `.env.local`, fill it, `npm i && npm run dev`.
