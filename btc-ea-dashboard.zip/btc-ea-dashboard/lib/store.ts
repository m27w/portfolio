import { Redis } from "@upstash/redis";

// Vercel's Upstash Marketplace integration injects UPSTASH_REDIS_REST_* on new
// stores, but stores migrated from the retired Vercel KV carry KV_REST_API_*.
// Accept either so the app works whichever way the store was provisioned.
const url = process.env.UPSTASH_REDIS_REST_URL ?? process.env.KV_REST_API_URL;
const token = process.env.UPSTASH_REDIS_REST_TOKEN ?? process.env.KV_REST_API_TOKEN;

if (!url || !token) {
  throw new Error(
    "Redis is not configured. Attach an Upstash Redis store to this Vercel project, " +
      "or set UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN locally."
  );
}

export const redis = new Redis({ url, token });

export const K = {
  heartbeat: (magic: number | string) => `ea:hb:${magic}`,
  magics: "ea:magics",
  trades: "ea:trades",
  rejects: "ea:rejects",
} as const;

// Heartbeat expires so a dead EA reads as stale rather than as "last known good
// state forever" - silence must look different from health.
export const HEARTBEAT_TTL_SECONDS = 180;
export const MAX_TRADES = 2000;
export const MAX_REJECTS = 5000;

export type Trade = {
  type: "trade";
  magic: number;
  symbol: string;
  open_time: string;
  close_time: string;
  dir: "BUY" | "SELL";
  entry: number;
  sl: number;
  tp: number;
  exit: number;
  lots: number;
  risk_pct: number;
  equity_at_entry: number;
  spread_pts: number;
  atr_pts: number;
  reason: string;
  r: number;
  net: number;
  balance: number;
};

export type Reject = {
  type: "reject";
  magic: number;
  symbol: string;
  ts: string;
  dir: string;
  filter: string;
  detail: string;
};

export type Heartbeat = {
  type: "heartbeat";
  magic: number;
  symbol: string;
  tf: string;
  ts: string;
  ccy: string;
  state: string;
  equity: number;
  balance: number;
  risk_pct: number;
  risk_money: number;
  lots_now: number;
  lot_min: number;
  trend: string;
  atr_pts: number;
  atr_price: number;
  atr_min: number;
  atr_max: number;
  atr_ok: boolean;
  spread_pts: number;
  spread_price: number;
  spread_max: number;
  spread_ok: boolean;
  cost_pct: number;
  cost_max: number;
  sl_preview: number;
  cost_ok: boolean;
  session_ok: boolean;
  weekend_block: boolean;
  news_block: boolean;
  lockout: boolean;
  consec_losses: number;
  day_pct: number;
  day_cap_pct: number;
  day_blocked: boolean;
  floor: number;
  floor_pct: number;
  halted: boolean;
  in_trade: boolean;
  pos_dir: string;
  pos_lots: number;
  pos_r: number;
  bars_in_trade: number;
  max_bars: number;
  be_armed: boolean;
  trailing: boolean;
  day_trades: number;
  day_wins: number;
  day_gross_r: number;
  day_max_dd: number;
  last_event: string;
  queued: number;
  received_at?: number;
};
